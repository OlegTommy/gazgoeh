# Интеграция в WPApplication твоей тестовой сборки

В APK application class:

```xml
android:name="com.wepie.wespy.base.WPApplication"
```

В smali найден метод:

```text
/mnt/data/apk_decoded/smali_classes4/com/wepie/wespy/base/WPApplication.smali
.method public final onCreate()V
```

Начало метода:

```smali
.method public final onCreate()V
    .locals 20
    move-object/from16 v1, p0
    const/4 v2, 0x0
    invoke-super/range {p0 .. p0}, Lcom/wepie/wespy/base/l;->onCreate()V
```

Для своей тестовой сборки можно вставить сразу после `invoke-super`:

```smali
    invoke-static {v1}, Lcom/wepie/tool/Tool;->install(Landroid/app/Application;)V
```

Почему `v1`: в этом методе `v1` уже содержит `p0`, то есть экземпляр `WPApplication`.

Важно: Java-классы `com.wepie.tool.*` должны быть добавлены в DEX, а `libTool.so` должен лежать в `lib/arm64-v8a/` и `lib/armeabi-v7a/`.

Для Unity-процессов `:weplaygame1` и `:weplaygame2` Android создаст Application заново, поэтому `Tool.install(this)` должен сработать и там, если процесс не выходит по ветке `isolated process`.
