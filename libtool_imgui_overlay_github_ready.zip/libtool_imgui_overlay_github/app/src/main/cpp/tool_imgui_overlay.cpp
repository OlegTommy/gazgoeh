#include <jni.h>
#include <android/log.h>
#include <GLES3/gl3.h>
#include <algorithm>

#include "imgui.h"
#include "imgui_impl_opengl3.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  "libTool", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "libTool", __VA_ARGS__)

static bool  g_initialized = false;
static bool  g_show_menu = true;
static int   g_width = 0;
static int   g_height = 0;
static float g_density = 1.0f;
static float g_slider = 0.50f;
static bool  g_checkbox = false;
static int   g_counter = 0;

static ImVec2 g_menu_pos  = ImVec2(24.0f, 80.0f);
static ImVec2 g_menu_size = ImVec2(430.0f, 360.0f);
static ImVec2 g_toggle_pos  = ImVec2(18.0f, 120.0f);
static ImVec2 g_toggle_size = ImVec2(96.0f, 56.0f);

static bool inside(float x, float y, const ImVec2& p, const ImVec2& s) {
    return x >= p.x && y >= p.y && x <= (p.x + s.x) && y <= (p.y + s.y);
}

static void apply_style() {
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 12.0f;
    style.FrameRounding = 8.0f;
    style.ScrollbarRounding = 8.0f;
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;
    style.ScaleAllSizes(std::max(1.0f, g_density));
}

extern "C" JNIEXPORT void JNICALL
Java_com_wepie_tool_ToolNative_nativeInit(JNIEnv*, jclass) {
    if (g_initialized) return;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;
    io.LogFilename = nullptr;

    apply_style();

    if (!ImGui_ImplOpenGL3_Init("#version 300 es")) {
        LOGE("ImGui_ImplOpenGL3_Init failed");
        return;
    }

    g_initialized = true;
    LOGI("initialized");
}

extern "C" JNIEXPORT void JNICALL
Java_com_wepie_tool_ToolNative_nativeResize(JNIEnv*, jclass, jint width, jint height, jfloat density) {
    g_width = width;
    g_height = height;
    g_density = density <= 0.0f ? 1.0f : density;

    if (g_initialized) {
        ImGuiIO& io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)g_width, (float)g_height);
        io.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_wepie_tool_ToolNative_nativeRender(JNIEnv*, jclass) {
    if (!g_initialized) return;

    glViewport(0, 0, g_width, g_height);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)g_width, (float)g_height);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();

    if (g_show_menu) {
        ImGui::SetNextWindowPos(g_menu_pos, ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(g_menu_size, ImGuiCond_FirstUseEver);
        bool open = true;
        if (ImGui::Begin("libTool.so ImGui", &open, ImGuiWindowFlags_NoCollapse)) {
            g_menu_pos = ImGui::GetWindowPos();
            g_menu_size = ImGui::GetWindowSize();

            ImGui::Text("Universal Activity overlay");
            ImGui::Separator();
            ImGui::Text("Screen: %d x %d", g_width, g_height);
            ImGui::Checkbox("Test checkbox", &g_checkbox);
            ImGui::SliderFloat("Test slider", &g_slider, 0.0f, 1.0f);
            if (ImGui::Button("Counter +1")) g_counter++;
            ImGui::SameLine();
            ImGui::Text("%d", g_counter);
            ImGui::Spacing();
            ImGui::TextWrapped("This menu is rendered by libTool.so on a transparent GLSurfaceView above the current Activity.");
            if (ImGui::Button("Hide menu")) g_show_menu = false;
        }
        ImGui::End();
        if (!open) g_show_menu = false;
    } else {
        ImGui::SetNextWindowPos(g_toggle_pos, ImGuiCond_Always);
        ImGui::SetNextWindowSize(g_toggle_size, ImGuiCond_Always);
        ImGui::Begin("##tool_toggle", nullptr,
                     ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoBackground);
        if (ImGui::Button("MENU", g_toggle_size)) g_show_menu = true;
        ImGui::End();
    }

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

extern "C" JNIEXPORT void JNICALL
Java_com_wepie_tool_ToolNative_nativeTouch(JNIEnv*, jclass, jint action, jfloat x, jfloat y) {
    if (!g_initialized) return;
    ImGuiIO& io = ImGui::GetIO();
    io.AddMousePosEvent(x, y);

    // Android MotionEvent constants: DOWN=0, UP=1, MOVE=2, CANCEL=3
    switch (action) {
        case 0: io.AddMouseButtonEvent(0, true); break;
        case 1: io.AddMouseButtonEvent(0, false); break;
        case 2: break;
        case 3: io.AddMouseButtonEvent(0, false); break;
        default: break;
    }
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_wepie_tool_ToolNative_nativeShouldCaptureTouch(JNIEnv*, jclass, jint action, jfloat x, jfloat y) {
    if (!g_initialized) return JNI_FALSE;
    if (g_show_menu && inside(x, y, g_menu_pos, g_menu_size)) return JNI_TRUE;
    if (!g_show_menu && inside(x, y, g_toggle_pos, g_toggle_size)) return JNI_TRUE;

    ImGuiIO& io = ImGui::GetIO();
    return io.WantCaptureMouse ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_wepie_tool_ToolNative_nativeToggleMenu(JNIEnv*, jclass) {
    g_show_menu = !g_show_menu;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_wepie_tool_ToolNative_nativeIsMenuVisible(JNIEnv*, jclass) {
    return g_show_menu ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_wepie_tool_ToolNative_nativeShutdown(JNIEnv*, jclass) {
    if (!g_initialized) return;
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    g_initialized = false;
    LOGI("shutdown");
}

jint JNI_OnLoad(JavaVM*, void*) {
    return JNI_VERSION_1_6;
}
