package com.wepie.tool;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public final class ToolLifecycle implements Application.ActivityLifecycleCallbacks {
    @Override public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}
    @Override public void onActivityStarted(Activity activity) {}

    @Override public void onActivityResumed(Activity activity) {
        ToolOverlayManager.onResume(activity);
    }

    @Override public void onActivityPaused(Activity activity) {
        ToolOverlayManager.onPause(activity);
    }

    @Override public void onActivityStopped(Activity activity) {}
    @Override public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}

    @Override public void onActivityDestroyed(Activity activity) {
        ToolOverlayManager.detach();
    }
}
