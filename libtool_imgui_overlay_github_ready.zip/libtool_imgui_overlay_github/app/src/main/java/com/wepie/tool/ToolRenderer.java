package com.wepie.tool;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.DisplayMetrics;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

final class ToolRenderer implements GLSurfaceView.Renderer {
    private final Context appContext;
    private int width;
    private int height;
    private float density = 1.0f;

    ToolRenderer(Context context) {
        this.appContext = context.getApplicationContext();
        DisplayMetrics dm = appContext.getResources().getDisplayMetrics();
        this.density = dm.density <= 0 ? 1.0f : dm.density;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        ToolNative.nativeInit();
        if (width > 0 && height > 0) {
            ToolNative.nativeResize(width, height, density);
        }
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        this.width = width;
        this.height = height;
        ToolNative.nativeResize(width, height, density);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        ToolNative.nativeRender();
    }
}
