package com.wepie.tool;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public final class ToolOverlayManager {
    private static final String TAG = "ToolOverlay";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static ToolGLSurfaceView overlayView;
    private static Activity attachedActivity;

    private ToolOverlayManager() {}

    public static void attach(final Activity activity) {
        if (activity == null) return;
        if (Looper.myLooper() != Looper.getMainLooper()) {
            MAIN.post(() -> attach(activity));
            return;
        }
        try {
            if (attachedActivity == activity && overlayView != null) return;
            detach();
            FrameLayout root = activity.findViewById(android.R.id.content);
            if (root == null) return;
            overlayView = new ToolGLSurfaceView(activity);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            );
            root.addView(overlayView, lp);
            attachedActivity = activity;
            Log.i(TAG, "attached to " + activity.getClass().getName());
        } catch (Throwable t) {
            Log.e(TAG, "attach failed", t);
        }
    }

    public static void detach() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            MAIN.post(ToolOverlayManager::detach);
            return;
        }
        try {
            if (overlayView != null) {
                ViewGroup parent = (ViewGroup) overlayView.getParent();
                if (parent != null) parent.removeView(overlayView);
                overlayView.onPause();
                overlayView = null;
            }
            ToolNative.nativeShutdown();
        } catch (Throwable t) {
            Log.e(TAG, "detach failed", t);
        } finally {
            attachedActivity = null;
        }
    }

    public static void onResume(Activity activity) {
        attach(activity);
        if (overlayView != null) overlayView.onResume();
    }

    public static void onPause(Activity activity) {
        if (overlayView != null) overlayView.onPause();
    }
}
