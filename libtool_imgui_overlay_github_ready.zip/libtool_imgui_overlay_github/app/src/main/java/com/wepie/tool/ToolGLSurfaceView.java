package com.wepie.tool;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public final class ToolGLSurfaceView extends GLSurfaceView {
    public ToolGLSurfaceView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);
        setZOrderOnTop(true);
        setPreserveEGLContextOnPause(true);
        setFocusable(false);
        setFocusableInTouchMode(false);
        setRenderer(new ToolRenderer(context));
        setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        float x = event.getX();
        float y = event.getY();

        boolean capture = ToolNative.nativeShouldCaptureTouch(action, x, y);
        if (capture) {
            ToolNative.nativeTouch(action, x, y);
            return true;
        }
        return false;
    }
}
