package com.wepie.tool;

public final class ToolNative {
    static {
        try {
            System.loadLibrary("Tool");
        } catch (Throwable t) {
            android.util.Log.e("ToolNative", "load libTool.so failed", t);
        }
    }

    private ToolNative() {}

    public static native void nativeInit();
    public static native void nativeResize(int width, int height, float density);
    public static native void nativeRender();
    public static native void nativeTouch(int action, float x, float y);
    public static native boolean nativeShouldCaptureTouch(int action, float x, float y);
    public static native void nativeToggleMenu();
    public static native boolean nativeIsMenuVisible();
    public static native void nativeShutdown();
}
