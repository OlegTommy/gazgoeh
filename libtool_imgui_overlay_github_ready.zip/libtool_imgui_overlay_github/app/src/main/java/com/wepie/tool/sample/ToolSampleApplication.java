package com.wepie.tool.sample;

import android.app.Application;
import com.wepie.tool.Tool;

public class ToolSampleApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        Tool.install(this);
    }
}
