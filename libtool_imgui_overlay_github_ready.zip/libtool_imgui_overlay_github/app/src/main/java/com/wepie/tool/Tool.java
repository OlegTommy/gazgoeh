package com.wepie.tool;

import android.app.Application;
import android.util.Log;

public final class Tool {
    private static boolean installed;

    private Tool() {}

    public static synchronized void install(Application app) {
        if (installed || app == null) return;
        installed = true;
        try {
            app.registerActivityLifecycleCallbacks(new ToolLifecycle());
            Log.i("Tool", "Tool overlay lifecycle installed");
        } catch (Throwable t) {
            Log.e("Tool", "install failed", t);
        }
    }
}
