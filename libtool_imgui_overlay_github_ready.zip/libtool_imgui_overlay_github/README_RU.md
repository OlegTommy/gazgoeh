# libTool.so ImGui Overlay для тестовой сборки

Это готовый Android/Gradle-проект для сборки `libTool.so` с Dear ImGui 1.92.8.
Меню рисуется не через Unity hook, а через прозрачный `GLSurfaceView`, который добавляется поверх текущей `Activity`. Такой вариант лучше подходит для тестовой сборки, где есть обычные Android-экраны, WebView/Cocos mini-games и Unity Activity.

## Что внутри

```text
app/src/main/java/com/wepie/tool/
  Tool.java
  ToolLifecycle.java
  ToolOverlayManager.java
  ToolGLSurfaceView.java
  ToolRenderer.java
  ToolNative.java

app/src/main/cpp/
  tool_imgui_overlay.cpp
  CMakeLists.txt
  third_party/imgui/        # Dear ImGui 1.92.8 уже вложен

.github/workflows/build.yml # сборка через GitHub Actions
```

## Как собрать через GitHub Actions

1. Создай пустой репозиторий на GitHub.
2. Загрузи в него всё содержимое этого архива.
3. Открой вкладку **Actions**.
4. Выбери workflow **Build libTool.so**.
5. Нажми **Run workflow**.
6. После окончания сборки скачай artifact **libTool-so**.

Внутри artifact будут:

```text
arm64-v8a/libTool.so
armeabi-v7a/libTool.so
```

## Как подключать к твоей тестовой сборке

В Java/Kotlin исходниках тестовой сборки добавь классы из пакета:

```text
com.wepie.tool
```

В `WPApplication.onCreate()` добавь:

```java
com.wepie.tool.Tool.install(this);
```

Если процессов несколько, например Unity запускается в `:weplaygame1` и `:weplaygame2`, код в `Application.onCreate()` должен выполняться и в этих процессах тоже. `ActivityLifecycleCallbacks` сам будет цеплять overlay к каждой Activity.

Нативные библиотеки положи в APK:

```text
lib/arm64-v8a/libTool.so
lib/armeabi-v7a/libTool.so
```

## Почему это должно работать шире, чем Unity-only hook

Этот проект создаёт отдельную прозрачную OpenGL-поверхность поверх Activity:

```text
Activity content
  ├─ главный экран / WebView / Cocos / UnityPlayer
  └─ ToolGLSurfaceView → libTool.so → ImGui
```

Поэтому меню рассчитано на:

```text
главное меню Android
обычные Activity
WebView/Cocos mini-games
Unity Activity
portrait/landscape экраны
```

## Важно про touch

Overlay не должен блокировать всю игру. Поэтому Java спрашивает у native-кода, надо ли забирать touch:

```java
ToolNative.nativeShouldCaptureTouch(action, x, y)
```

Клик по окну меню забирает ImGui, клик вне меню возвращает `false`, чтобы событие ушло в нижний экран.

## Ограничения

- Это исходники и workflow для сборки. В этом окружении Android NDK не установлен, поэтому бинарник собирается через GitHub Actions или локально в Android Studio.
- В некоторых Unity/Vulkan/fullscreen Surface случаях может понадобиться настройка `setZOrderOnTop(true)` / порядка добавления overlay.
- Это предназначено для твоей тестовой сборки, где у тебя есть право вносить изменения.
